    DK Bukittinggi - Mobile Starter (Expo + Firebase Auth)

    Setup:
    1. cd mobile
    2. npm install
    3. open /mobile/src/firebase/config.js and paste your firebaseConfig (web app) values
    4. npx expo start

Notes:
- For Phone Auth testing, add a test phone number in Firebase Console to avoid SMS costs.
- Replace YOUR_BACKEND_IP with your backend server IP when testing order flow.
